class Punto:
    def __init__(self, coordenadas=None):
        self.coordenadas = [] if coordenadas is None else coordenadas
        if self.coordenadas:
            self.x = self.coordenadas[0]
            self.y = self.coordenadas[1]
        else:
            self.x = 0
            self.y = 0