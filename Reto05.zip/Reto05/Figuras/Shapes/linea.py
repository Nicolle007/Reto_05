from .punto import Punto
class Linea:
    def __init__(self, punto_inicial=None, punto_final=None, longitud=0.0):
        self.punto_inicial = punto_inicial
        self.punto_final = punto_final
        self.longitud = longitud