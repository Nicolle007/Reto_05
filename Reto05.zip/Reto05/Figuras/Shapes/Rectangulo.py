import math
from .shape import Shape
from .punto import Punto
from .linea import Linea

class Rectangulo(Shape):
    def __init__(self, vertices, bordes, angulos_interiores):
        super().__init__(vertices, bordes, angulos_interiores)

    def compute_area(self):
        raise NotImplementedError("Las subclases deben implementar el método")


class Cuadrado(Rectangulo):
    def __init__(self, vertices, bordes, angulos_interiores):
        super().__init__(vertices, bordes, angulos_interiores)

    def compute_area(self):
        lado = int(self._bordes[0].longitud)
        Area = lado * lado
        return Area