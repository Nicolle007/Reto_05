import math

class Shape:
    def __init__(self, vertices, bordes, angulos_interiores):
        self._vertices = [] if vertices is None else vertices
        self._bordes = [] if bordes is None else bordes
        self._angulos_interiores = [] if angulos_interiores is None else angulos_interiores

    def get_vertices(self):
        return self._vertices

    def set_name(self, otros_vertices):
        if otros_vertices:
            self._vertices = otros_vertices

    def get_bordes(self):
        return self._bordes

    def set_bordes(self, otros_bordes):
        if otros_bordes:
            self._bordes = otros_bordes

    def get_angulos(self):
        return self._angulos_interiores

    def set_angulos(self, otros_angulos):
        if otros_angulos:
            self._angulos_interiores = otros_angulos

    def is_regular(self):
        c = 0
        regular = True
        while c < len(self._bordes) - 1:
            if (self._bordes[c].longitud == self._bordes[c + 1].longitud and
                self._angulos_interiores[c] == self._angulos_interiores[c + 1]):
                c += 1
            else:
                regular = False
                break
        return regular

    def compute_area(self):
        raise NotImplementedError("Las subclases deben implementar el método")

    def compute_perimeter(self):
        total = 0
        for i in self._bordes:
            total += i.longitud
        return total

    def compute_inner_angles(self):
        total = 0
        for i in self._angulos_interiores:
            total += i
        return total




